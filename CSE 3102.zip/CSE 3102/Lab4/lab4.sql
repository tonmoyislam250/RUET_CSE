SELECT *
FROM actor;


/* 1.1 Display the name, IMDb rating and genre of all the movies with an IMDB rating greater than or equal to 8.0.*/
SELECT Movie_Name,
    IMDB_Rating,
    Genre
FROM movie
WHERE IMDB_Rating >= 8.0;


/* Query 1.2: Find how many movies are there in each genre with an IMDB rating greater than or equal to 8.0.*/
SELECT Genre,
    COUNT(Genre) AS No_Of_Movies
FROM movie
WHERE IMDB_Rating >= 8.0
GROUP BY Genre;





/* 1.3 Find the name and the average IMDb rating of those genres whose average IMDb rating is greater than or equal to 8.0.*/
SELECT Genre, AVG(IMDB_Rating) AS Average_Rating
FROM movie
GROUP BY Genre
HAVING AVG(IMDB_Rating) >= 8.0;


/* 1.4 Find the name, number of films and number of awards of the director who directed the most number of movies.*/
SELECT Director_Name,
    No_Of_Films,
    No_Of_Awards
FROM director
WHERE No_Of_Films = (
        SELECT MAX(No_Of_Films)
        FROM director
    );

/* 1.5 Find the name, current age, number of films and number of awards of the youngest actor. */

SELECT Actor_Name,
    (YEAR(CURRENT_DATE) - Birth_Year) AS Current_Age,
    No_Of_Films,
    No_Of_Awards
FROM actor
WHERE Birth_Year = (
        SELECT MAX(Birth_Year)
        FROM actor
    );

/* 2.1 Find the name, number of films as a director, number of films as
an actor, number of awards as a director and number of awards as an actor of
all the directors. (If a director never acted in any film then number of films
and number of awards as an actor will be null) */

SELECT D.Director_Name,
    D.No_Of_Films AS No_Of_Films_Director,
    A.No_Of_Films AS No_Of_Films_Actor,
    D.No_Of_Awards AS No_Of_Awards_Director,
    A.No_Of_Awards AS No_Of_Awards_Actor
FROM director D
LEFT JOIN actor A ON D.Person_ID = A.Person_ID;

/* 2.2 Find the name, number of films as a director, number of films as
an actor, number of awards as a director and number of awards as an actor of
all the actors and directors. */

SELECT D.Director_Name,
    D.No_Of_Films AS No_Of_Films_Director,
    A.No_Of_Films AS No_Of_Films_Actor,
    D.No_Of_Awards AS No_Of_Awards_Director,
    A.No_Of_Awards AS No_Of_Awards_Actor
FROM director D
JOIN actor A ON D.Person_ID = A.Person_ID;